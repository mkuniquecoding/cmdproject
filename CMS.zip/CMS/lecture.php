<?php
    session_start();
    include('connection.php');
    $std_name=$_SESSION['stdname'];
   if (!isset($std_name)) {
     header('location:start.html');
   }
   $profile = "SELECT * FROM student WHERE Email='$std_name'";
    $query=mysqli_query($con,$profile);
    $num=mysqli_num_rows($query);
    if ($num==1) {
         while ($row=mysqli_fetch_assoc($query)) {
            $class=$row['Class'];
         }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <style>
        .navigator{
            z-index: 1000;
        }
        .main-container .lecture{
           padding: 20px;
           background: #000;
           width: 100%;
           box-sizing: border-box;
           z-index: 0;
        }
        .main-container .search-date{
           position: relative;
           width: 100%;
           height: 50px;
           color: #fff; 
        }
        @media(max-width: 767px){
            .main-container .search-date{
                height: 80px;
            }
        }
        .main-container .search-date input[type="date"]{
            height: 40px;
            width: 300px;
        }
        .main-container .display-lecture table tr th{
            background: #F17C2A;
        }
    </style>
</head>
<body style="background-color: rgba(190, 233, 72, 0.5);">
    <div class="wrapper">
   <div class="navigator">
       <ul>
        <li class="active">
            <a href="#">
                <span class="icon"><i class="fa fa-cube" aria-hidden="true"></i></span>
                <span class="title">CMS</span>
            </a>
        </li>
           <li>
               <a href="index.php">
                   <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                   <span class="title">Home</span>
               </a>
           </li>
           <li>
            <a href="#">
                <span class="icon"><i class="fa fa-bookmark" aria-hidden="true"></i></span>
                <span class="title">About</span>
            </a>
        </li>
        <li>
            <a href="lecture.php">
                <span class="icon"><i class="fa fa-leanpub" aria-hidden="true"></i></span>
                <span class="title">Lecture</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                <span class="title">Routine</span>
            </a>
        </li>
        <li>
            <a href="std_profile.php">
                <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                <span class="title">Profile</span>
            </a>
        </li>
        <li>
            <a href="Logout.php">
                <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                <span class="title">Logout</span>
            </a>
        </li>
       </ul>
   </div>
   <div class="main-container">
    <div class="lecture">
        <div class="search-date">
            <form method="post" action="#">
                <label>Select Date</label>
                <input type="date" name="d1" required="">
                <input type="submit" name="search" value="Search" class="btn btn-warning">
            </form>
        </div>
    </div>
        <div class="display-lecture">
            <?php
                if (isset($_POST['search'])) {
                    $date=$_POST['d1'];

                    $profile = "SELECT * FROM lecture WHERE Dates='$date' && Class='$class'";
                    $query=mysqli_query($con,$profile);
                    $num=mysqli_num_rows($query);
                    if ($num==1) {
            ?>
                <table class="table table-striped table-hover" border="1">
                    <tr>
                        <th>Date</th>
                        <th>Teache's Name</th>
                        <th>Subject Name</th>
                        <th>Topic Discuss</th>
                        <th>Class</th>
                        <th>Lecture</th>
                    </tr>

            <?php
                         while ($row=mysqli_fetch_assoc($query)) {
                            $lid=$row['sno'];
            ?>
                    <tr>
                        <td><?php echo $date=$row['Dates']; ?></td>
                        <td><?php echo $teacher=$row['Teacher_Name']; ?></td>
                        <td><?php echo $subject=$row['Subject']; ?></td>
                        <td><?php echo $topic=$row['Topic']; ?></td>
                        <td><?php echo $class=$row['Class']; ?></td>
                        <td><a href="display_lecture.php?lecture_id=<?php echo $row['sno']; ?>" class="btn btn-warning">View</a></td>
                    </tr>
                </table>
            <?php
                            
                         }
                    }
                    else{
                        echo "No Lecture Available";
                    }
                }
            ?>
        </div>
    
   </div>
   </div> 
   <div class="toggle" onclick="toggleMenu()"></div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script>
        function toggleMenu(){
            let navigation = document.querySelector('.navigator');
            let toggle = document.querySelector('.toggle');
            navigation.classList.toggle('active');
            toggle.classList.toggle('active');
        }
    </script>
</body>
</html>