<?php
include('connection.php');
	$lid = $_GET['lecture_id'];
	$profile = "SELECT * FROM lecture WHERE sno='$lid'";
    $query=mysqli_query($con,$profile);
    $num=mysqli_num_rows($query);
    if ($num==1) {
         while ($row=mysqli_fetch_assoc($query)) {
            $subject= $row['Subject'];
            $topic= $row['Topic'];
            $date= $row['Dates'];
            $video= $row['Video'];
         }
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Class Lecture Video</title>
	<style type="text/css">
		.Lecture{
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%,-50%);
			background: #2ACDF1;
			border-radius: 5px;
			border: 1px solid #DCDFE0;
			box-shadow: 5px 5px 10px #B5EBF7;
		}
		.Lecture .Lecture-details{
			padding: 20px;
		}
		.Lecture .Lecture-details button{
			background: #FA4E20;
			height: 40px;
			width: 120px;
			border-radius: 5px;
			border: none;
			cursor: pointer;
		}
		.Lecture .Lecture-details button a{
			color: #fff;
			text-decoration: none;
		}
		@media(max-width: 767px){
			iframe{
				height: 200px;
				width: 300px;
			}
		}
	</style>
</head>
<body>
	<div class="Lecture">
		<div class="Lecture-details">
			<h1>Subject - <?php echo $subject;  ?> </h1>
			<h3>Topic Discuss - <?php echo $topic; ?></h3>
			<p>Date - <?php echo $date; ?> </p>
			<span> <?php echo $video; ?></span>
			<br><br>
			<button><a href="lecture.php">Go Back</a></button>
		</div>
	</div>
</body>
</html>