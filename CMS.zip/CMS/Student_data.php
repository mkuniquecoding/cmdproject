<?php
	session_start();
    include('connection.php');
    $admin_name=$_SESSION['adminname'];
   if (!isset($admin_name)) {
     header('location:admin_login.php');
   }
    $name=$_POST['s1'];
    $fname=$_POST['s2'];
    $class=$_POST['s3'];
    $roll=$_POST['s4'];
    $email=$_POST['s5'];
    $phone=$_POST['s6'];

	$check="SELECT * FROM Student where Email='$email'";
	$result=mysqli_query($con,$check);
	if (mysqli_num_rows($result)==1) {
		echo "username already available.....!!";
	}
	else{
		$query="INSERT INTO Student(Std_Name,Fathers_Name,Class,Roll,Email,Phone) VALUES('$name','$fname','$class','$roll','$email','$phone')";
		$res=mysqli_query($con,$query);
		if ($res) {
			echo "Successfully data inserted";
		}
		else{
			echo "something wrong...";
		}
	}

?>