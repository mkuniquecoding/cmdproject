<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .login-box{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            width: 350px;
            height: 400px;
            background: rgba(255,255,255,.5);
            border: 1px solid #B9B9B9;
            box-shadow: 5px 5px 10px rgba(0,0,0,0.5);
            box-sizing: border-box;
        }
        .login-box .content{
            padding: 15px;
            position: relative;
        }
        .login-box .content h1{
            text-align: center;
            color: #F58C1C;
            margin-bottom: 15px;
        }
        .login-box .content label{
            color: #000;
            font-size: 16px;
        }
        .login-box form input{
            width: 100%;
            height: 40px;
            margin-bottom: 20px;
        }
        .login-box form input[type="submit"]{
            background-color: #F58C1C;
            border: none;
            outline: none;
            cursor: pointer;
            color: #fff;
            font-size: 18px;
        }
        .login-box form p{
            color: #000;
            text-align: center;
            margin-bottom: 10px;
        }
        .login-box form p a{
            color: #F58C1C;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <div class="content">
            <h1>Admin Login</h1>
            <form action="#" method="post">
                <label for="useremail">Email</label>
                <input type="email" name="email">
                <label for="Userpassword">Password</label>
                <input type="password" name="password">
                <input type="submit" name="adminlogin" value="Login">
                <p><a href="adminforgetpassword.php">Forget Password</a></p>
            </form>
        </div>
    </div>
</body>
</html>
<?php
    session_start();
    include('connection.php');
    if (isset($_POST['adminlogin'])) {
        $email = $_POST['email'];
        $pass= $_POST['password'];
        $query="SELECT * FROM admin WHERE email='$email' && password='$pass'";
        $result=mysqli_query($con,$query);
        $row=mysqli_num_rows($result);
        if ($row>0) {
            $_SESSION['adminname']=$email;
            header('location:admin_dashboard.php');
        }
        else{
            echo "<script>alert('email or password wrong....!!');</script>";
        }
    }
?>
