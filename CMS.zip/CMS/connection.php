<?php
	$con=mysqli_connect("localhost","root","","cms");
	if (!$con) {
		echo "not connected";
	}
?>