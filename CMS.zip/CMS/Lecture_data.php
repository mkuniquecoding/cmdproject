<?php
	session_start();
    include('connection.php');
    $admin_name=$_SESSION['adminname'];
   if (!isset($admin_name)) {
     header('location:admin_login.php');
   }
    $name=ucwords($_POST['l1']);
    $topic=ucwords($_POST['l2']);
    $class=$_POST['l3'];
    $video=$_POST['l4'];
    $subject=$_POST['l5'];
    $date=date("Y/m/d");

		$query="INSERT INTO lecture(Teacher_Name,Topic,Class,Video,Dates,Subject) VALUES('$name','$topic','$class','$video','$date','$subject')";
		$res=mysqli_query($con,$query);
		if ($res) {
			echo "Successfully data inserted";
		}
		else{
			echo "something wrong...";
		}

?>