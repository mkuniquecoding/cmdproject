<?php
    session_start();
    include('connection.php');
    $std_name=$_SESSION['stdname'];
   if (!isset($std_name)) {
     header('location:start.html');
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <style>
        .wrapper{
            display: flex;
        }
        .navigator ul li.active{
            background-color: darksalmon;
        }
        .navigator ul li.active a{
            font-size: 24px;
        }
        .navigator{
            position: fixed;
            width: 250px;
            height: 100%;
            background-color: #000;
            transition: 0.5s;
            z-index: 1000;
        }
        .navigator ul{
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
        }
        .navigator ul li{
            position: relative;
            list-style: none;
            width: 100%;
        }
        .navigator ul li:hover{
            background-color: darksalmon;
        }
        .navigator ul li a{
            position: relative;
            display: block;
            width: 100%;
            display: flex;
            color: #fff;
            text-decoration: none;
        }
        .navigator ul li a .icon{
            position: relative;
            display: block;
            min-width: 60px;
            line-height: 60px;
            height: 60px;
            text-align: center;
        }
        .navigator ul li a .icon .fa{
            font-size: 24px;
        }
        .navigator ul li a .title{
            position: relative;
            display: block;
            padding: 0 10px;
            line-height: 60px;
            height: 60px;
            text-align: start;
        }
        .toggle{
            position: absolute;
            right: 10px;
            top: 10px;
            width: 60px;
            height: 60px;
            background-color: lightcoral;
            cursor: pointer;
            display: none;
        }
        .toggle.active{
            background-color: coral;
        }
        .toggle::before{
            content: '\f0c9';
            font-family: fontAwesome;
            position: absolute;
            width: 100%;
            height: 100%;
            line-height: 60px;
            text-align: center;
            font-size: 24px;
        }
        .toggle.active:before{
            content: '\f00d';
        }
        @media(max-width: 767px){
            .toggle{
                display: block;
            }
            .navigator{
                left: -260px;
            }
            .navigator.active{
                left: 0;
                width: 60%;
            }
            
        }
        .main-container{
            margin-left: 250px;
            transition: all .5s ease;
        }
        .profile{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            background: rgba(245, 229, 92, 0.74);
            padding: 20px;
        }
        .profile > div{
            padding: 10px 0;
        }
        .profile span{
            font-weight: bold;
        }
        @media(max-width: 767px){
            .main-container{
                margin-left: 0px;
            }
        }
    </style>
</head>
<body style="background-color: rgba(190, 233, 72, 0.5);">
    <div class="wrapper">
   <div class="navigator">
       <ul>
        <li class="active">
            <a href="#">
                <span class="icon"><i class="fa fa-cube" aria-hidden="true"></i></span>
                <span class="title">CMS</span>
            </a>
        </li>
           <li>
               <a href="index.php">
                   <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                   <span class="title">Home</span>
               </a>
           </li>
           <li>
            <a href="#">
                <span class="icon"><i class="fa fa-bookmark" aria-hidden="true"></i></span>
                <span class="title">About</span>
            </a>
        </li>
        <li>
            <a href="lecture.php">
                <span class="icon"><i class="fa fa-leanpub" aria-hidden="true"></i></span>
                <span class="title">Lecture</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                <span class="title">Routine</span>
            </a>
        </li>
        <li class="active">
            <a href="std_profile.php">
                <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                <span class="title">Profile</span>
            </a>
        </li>
        <li>
            <a href="Logout.php">
                <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                <span class="title">Logout</span>
            </a>
        </li>
       </ul>
   </div>
   <div class="main-container">
    <div class="profile">

       <?php
            $profile = "SELECT * FROM student WHERE Email='$std_name'";
            $query=mysqli_query($con,$profile);
            $num=mysqli_num_rows($query);
            if ($num==1) {
                 while ($row=mysqli_fetch_assoc($query)) {
                    $name= $row['Std_Name'];
                    $fname= $row['Fathers_Name'];
                    $email= $row['Email'];
                    $phone= $row['Phone'];
                    $class= $row['Class'];
                    $roll= $row['Roll'];
                 }
            }
       ?>
       <div>
           <span>Name -</span> <?php echo $name; ?>
       </div>
       <div>
           <span>Fathet's Name -</span> <?php echo $fname; ?>
       </div>
       <div>
           <span>Email -</span> <?php echo $email; ?>
       </div>
       <div>
           <span>Phone -</span> <?php echo $phone; ?>
       </div>
       <div>
           <span>Class Standard -</span> <?php echo $class; ?>
       </div>
       <div>
           <span>Roll No. -</span> <?php echo $roll; ?>
       </div>
    </div>
   </div>
   </div> 
   <div class="toggle" onclick="toggleMenu()"></div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script>
        function toggleMenu(){
            let navigation = document.querySelector('.navigator');
            let toggle = document.querySelector('.toggle');
            navigation.classList.toggle('active');
            toggle.classList.toggle('active');
        }
    </script>
</body>
</html>