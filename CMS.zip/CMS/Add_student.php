<?php
    session_start();
    include('connection.php');
    $admin_name=$_SESSION['adminname'];
   if (!isset($admin_name)) {
     header('location:admin_login.php');
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <style>
        .wrapper{
            display: flex;
        }
        .navigator ul li.active{
            background-color: darksalmon;
        }
        .navigator ul li.active a{
            font-size: 24px;
        }
        .navigator{
            position: fixed;
            width: 250px;
            height: 100%;
            background-color: #000;
            transition: 0.5s;
            z-index: 10000;
        }
        .navigator ul{
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
        }
        .navigator ul li{
            position: relative;
            list-style: none;
            width: 100%;
        }
        .navigator ul li:hover{
            background-color: darksalmon;
        }
        .navigator ul li a{
            position: relative;
            display: block;
            width: 100%;
            display: flex;
            color: #fff;
            text-decoration: none;
        }
        .navigator ul li a .icon{
            position: relative;
            display: block;
            min-width: 60px;
            line-height: 60px;
            height: 60px;
            text-align: center;
        }
        .navigator ul li a .icon .fa{
            font-size: 24px;
        }
        .navigator ul li a .title{
            position: relative;
            display: block;
            padding: 0 10px;
            line-height: 60px;
            height: 60px;
            text-align: start;
        }
        .toggle{
            position: absolute;
            right: 10px;
            top: 10px;
            width: 60px;
            height: 60px;
            background-color: lightcoral;
            cursor: pointer;
            display: none;
        }
        .toggle.active{
            background-color: coral;
        }
        .toggle::before{
            content: '\f0c9';
            font-family: fontAwesome;
            position: absolute;
            width: 100%;
            height: 100%;
            line-height: 60px;
            text-align: center;
            font-size: 24px;
        }
        .toggle.active:before{
            content: '\f00d';
        }
        @media(max-width: 767px){
            .toggle{
                display: block;
            }
            .navigator{
                left: -260px;
            }
            .navigator.active{
                left: 0;
                width: 60%;
            }
            
        }
        .main-container{
            margin-left: 250px;
            transition: all .5s ease;
        }
        .main-container .welcome{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            text-align: center;
            width: 700px;
        }
        
        @media(max-width: 767px){
            .main-container{
                margin-left: 0px;
            }
            .main-container .welcome h1{
                font-size: 40px;
            }
        }
        /*------------Student Registration-------------*/
        .Student-box{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            width: 40%;
            height: 93%;
            background: rgba(255,255,255,.5);
            border: 1px solid #B9B9B9;
            box-shadow: 5px 5px 10px rgba(0,0,0,0.5);
            box-sizing: border-box;
        }
        @media(max-width: 767px){
           .Student-box{
            width: 100%;
            height: 100%;
            box-sizing: border-box;
           } 
        }
        .Student-box .content{
            padding: 15px;
        }
        .Student-box .content h1{
            text-align: center;
            margin-bottom: 20px;
        }
        .Student-box .content input,
        .Student-box .content select{
            width: 100%;
            height: 40px;
            outline: none;
            border-radius: 5px;
            border: none;
            border: 1px solid #333;
            padding-left: 5px;
            background: transparent;
        }
        .Student-box .content input:focus,
        .Student-box .content select:focus{
            border-color: #F58C1C;
        }
        .Student-box form input[type="submit"]{
            background-color: #F58C1C;
            border: none;
            outline: none;
            cursor: pointer;
            color: #fff;
            font-size: 18px;
            margin-top: 10px;
        }
        #message{
            color: #E64930;
            display: none;
        }

    </style>
</head>
<body style="background-color: rgba(190, 233, 72, 0.5);">
    <div class="wrapper">
   <div class="navigator">
       <ul>
        <li class="active">
            <a href="#">
                <span class="icon"><i class="fa fa-cube" aria-hidden="true"></i></span>
                <span class="title">CMS</span>
            </a>
        </li>
           <li>
               <a href="admin_dashboard.php">
                   <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                   <span class="title">Home</span>
               </a>
           </li>
           <li class="active">
            <a href="Add_student.php">
                <span class="icon"><i class="fa fa-users" aria-hidden="true"></i></span>
                <span class="title">Add Student</span>
            </a>
        </li>
           
        <li>
            <a href="Add_Lecture.php">
                <span class="icon"><i class="fa fa-leanpub" aria-hidden="true"></i></span>
                <span class="title">Lecture</span>
            </a>
        </li>
        <li>
            <a href="Add_Routine.php">
                <span class="icon"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                <span class="title">Routine</span>
            </a>
        </li>
        <li>
            <a href="#">
                <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                <span class="title">Profile</span>
            </a>
        </li>
        <li>
            <a href="logout.php">
                <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                <span class="title">Logout</span>
            </a>
        </li>
       </ul>
   </div>
   <!---Main Body Start----------------->
   <div class="main-container">
    <div class="Student-box">
        <div class="content">
            <div id="message"></div>
            <h1>Add Student</h1>
            <form method="post">
                <label>Student Name</label>
                <input type="text" name="s1" id="name">
                <label>Father's Name</label>
                <input type="text" name="s2" id="fathername">
                <label>Class Standard</label>
                <select name="s3" id="class">
                    <option></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                </select>
                <label>Roll No.</label>
                <input type="Number" name="s4" id="roll">
                <label>Email</label>
                <input type="email" name="s5" id="email">
                <label>Phone</label>
                <input type="text" name="s6" id="phone">
                <input type="submit" name="addstd" id="addstd">

            </form>
        </div>
    </div>
   </div>
   <!----------End Main Body--------------->
   </div> 
   <div class="toggle" onclick="toggleMenu()"></div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script>
        function toggleMenu(){
            let navigation = document.querySelector('.navigator');
            let toggle = document.querySelector('.toggle');
            navigation.classList.toggle('active');
            toggle.classList.toggle('active');
        }
        $(document).ready(function(){
            $('#addstd').click(function(e){
                e.preventDefault();
            if ($('#name').val()=='') {
            alert('Name is Required...!!');
            $('#name').focus();
            return false;
            }
            else if ($('#name').val().length < 3) {
               alert('First name must be 3 or more character..!!');
                $('#name').focus();
                return false;
            }
            else if (!isNaN($('#name').val())) {
                alert('Numbers is not allowed..!!');
                 $('#name').focus();
                return false;
            }
            else if ($('#fathername').val()=='') {
            alert('Father Name is Required...!!');
             $('#fathername').focus();
            return false;
            }
            else if ($('#fathername').val().length < 3) {
               alert('First name must be 3 or more character..!!');
                $('#fathername').focus();
                return false;
            }
            else if (!isNaN($('#fathername').val())) {
                alert('Numbers is not allowed..!!');
                 $('#fathername').focus();
                return false;
            }
            else if ($('#class').val()=='') {
            alert('Class Name is Required...!!');
             $('#class').focus();
            return false;
            }
             else if ($('#roll').val()=='') {
            alert('Roll No Name is Required...!!');
             $('#roll').focus();
            return false;
            }
            else if ($('#email').val()=='') {
             alert('Email ID No Name is Required...!!');
             $('#email').focus();
                return false;
            }
            else if (!validateEmail($('#email').val())) {
             alert('Email is not Valid...!!');
             $('#email').focus();
            }
            else if ($('#phone').val()=='') {
                alert('Phone no. is required...!!');
                $('#phone').focus();
                return false;
            }
            else if (isNaN($('#phone').val())) {
                alert('only Number are allowed...!!');
                $('#phone').focus();
                return false;
            }
            else if ($('#phone').val().length!=10) {
                alert('Phone no. must be of 10 digits...!!');
                $('#phone').focus();
                return false;
            }
            else{
                $.ajax({
                    url:'Student_data.php',
                    method:'post',
                    data:$('form').serialize(),
                    dataType:"text",
                    success:function(strMessage){
                        $('#message').show();
                        $('#message').text(strMessage);
                    }
                });
            }


            function validateEmail($email){
                var emailReg=/^([a-zA-Z0-9_\.\_\+])+\@(([a-zA-Z0-9])+\.)+([a-zA-Z0-9]{2,4})+$/;
                return emailReg.test($email);
            }
            })
        })
    </script>
</body>
</html>
